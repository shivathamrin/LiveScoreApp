import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Live Score',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
        ),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Live Score'),
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Header
            Column(
              children: [
                Text('Glad to see you,'),
                Text(
                  'Esther Howard!',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                ),
              ],
            ),
            Column(
              textDirection: TextDirection.ltr,
              children: [
                TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Find your favorite club',
                  ),
                ),
                Text(
                  'Live Score',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                ),
              ],
            ),

            // Match list
            Column(
              children: [
                // Live match
                Column(
                  children: [
                    Card(
                      child: ListTile(
                        title: Text('Premiere League'),
                        subtitle: Text('Arsenal 2 : 1 Chelsea'),
                        trailing: Text('78'),
                      ),
                    ),
                    Card(
                      child: ListTile(
                        title: Text('La Liga'),
                        subtitle: Text('Real Madrid 3 : 0 Barcelona'),
                        trailing: Text('FT'),
                      ),
                    ),
                  ],
                ),
              ],
            ),

            //Finished match
            Column(
              textDirection: TextDirection.ltr,
              children: [
                Text(
                  'Finished Matches',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                ),
              ],
            ),
            Column(
              children: [
                Column(
                  children: [
                    Card(
                      child: ListTile(
                        title: Text('Champions League'),
                        subtitle: Text('Juventus 1 : 0 Paris Saint Germain'),
                        trailing: Text('FT'),
                      ),
                    ),
                    Card(
                      child: ListTile(
                        title: Text('League B'),
                        subtitle: Text('Bayern Munchen 0 : 2 Borrusia'),
                        trailing: Text('FT'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notification',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
